import { Metadata } from "next";
import { Suspense } from "react";
import { getCatalogSEO } from "@/lib/seo";
import CatalogPage from "@/components/catalog/catalog-page";
import CatalogSkeleton from "@/components/catalog/catalog-skeleton";

export const metadata: Metadata = getCatalogSEO();

export default function MobilPage() {
    return (
            <div className="min-h-screen bg-gray-50 container mx-auto px-4 sm:px-6 lg:px-8 max-w-7xl py-6 lg:py-8">
                <Suspense fallback={<CatalogSkeleton />}>
                    <CatalogPage />
                </Suspense>
            </div>
    );
}