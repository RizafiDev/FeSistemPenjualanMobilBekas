"use client";

import { useState } from "react";
import { NextSeo } from "next-seo";
import Link from "next/link";
import Image from "next/image";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import CarSearch from "@/components/car/car-search";
import CarCard from "@/components/car/car-card";
import {
    Car,
    Shield,
    Award,
    Users,
    ArrowRight,
    CheckCircle,
    Star,
    Clock,
    MapPin,
    Phone,
    TrendingUp,
    Heart,
    Zap,
} from "lucide-react";
import { useMobils, useMereks, useKategoris } from "@/lib/hooks";
import { defaultSEO } from "@/lib/seo";
import type { CarSearchFilters } from "@/lib/validations";
import type { Mobil } from "@/lib/types";

export default function HomePage() {
    const [searchFilters, setSearchFilters] = useState<CarSearchFilters>({});
    const { data: mobilsData } = useMobils();
    const { data: mereksData } = useMereks();
    const { data: kategorisData } = useKategoris();

    // Handle data safely
    const mobils = Array.isArray(mobilsData?.data)
        ? (mobilsData.data as Mobil[])
        : [];
    const mereks = Array.isArray(mereksData?.data) ? mereksData.data : [];
    const kategoris = Array.isArray(kategorisData?.data) ? kategorisData.data : [];

    const featuredCars = mobils.slice(0, 6);

    const handleSearch = (filters: CarSearchFilters) => {
        setSearchFilters(filters);
        // Navigate to catalog page with filters
        const params = new URLSearchParams();
        Object.entries(filters).forEach(([key, value]) => {
            if (value !== undefined && value !== "") {
                params.set(key, value.toString());
            }
        });
        window.location.href = `/catalog?${params.toString()}`;
    };

    return (
        <>
            <NextSeo {...defaultSEO} />

            {/* Hero Section - Enhanced */}
            <section className="relative overflow-hidden bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100">
                {/* Background Decoration */}
                <div className="absolute inset-0 bg-[linear-gradient(45deg,transparent_25%,rgba(59,130,246,0.05)_50%,transparent_75%)] bg-[length:60px_60px]"></div>
                <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-bl from-blue-200/30 to-transparent rounded-full blur-3xl"></div>
                <div className="absolute bottom-0 left-0 w-96 h-96 bg-gradient-to-tr from-indigo-200/30 to-transparent rounded-full blur-3xl"></div>
                
                <div className="container relative z-10 py-20 lg:py-32">
                    <div className="grid lg:grid-cols-2 gap-12 items-center">
                        <div className="space-y-8">
                            <div className="space-y-6">
                                <Badge variant="secondary" className="w-fit bg-blue-100 text-blue-800 border-0 font-semibold px-4 py-2">
                                    <TrendingUp className="w-4 h-4 mr-2" />
                                    Platform Terpercaya #1 Indonesia
                                </Badge>
                                <h1 className="text-4xl lg:text-6xl font-bold text-gray-900 leading-tight">
                                    Temukan
                                    <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-indigo-600 block">
                                        Mobil Bekas
                                    </span>
                                    Impian Anda
                                </h1>
                                <p className="text-xl text-gray-600 leading-relaxed max-w-lg">
                                    Ribuan pilihan mobil bekas berkualitas dengan harga terbaik. 
                                    Garansi resmi, pemeriksaan menyeluruh, dan layanan terpercaya.
                                </p>
                            </div>

                            {/* Enhanced Statistics */}
                            <div className="grid grid-cols-3 gap-6">
                                {[
                                    { number: "1000+", label: "Mobil Tersedia", icon: Car },
                                    { number: "50K+", label: "Pelanggan Puas", icon: Users },
                                    { number: "98%", label: "Rating Kepuasan", icon: Star }
                                ].map((stat, index) => (
                                    <div key={index} className="text-center group">
                                        <div className="flex items-center justify-center mb-2">
                                            <stat.icon className="w-5 h-5 text-blue-600 mr-2" />
                                            <div className="text-2xl lg:text-3xl font-bold text-blue-600 group-hover:scale-110 transition-transform">
                                                {stat.number}
                                            </div>
                                        </div>
                                        <div className="text-sm text-gray-600 font-medium">
                                            {stat.label}
                                        </div>
                                    </div>
                                ))}
                            </div>

                            {/* Enhanced CTA Buttons */}
                            <div className="flex flex-col sm:flex-row gap-4">
                                <Button size="lg" className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 shadow-lg hover:shadow-xl transition-all duration-300" asChild>
                                    <Link href="/catalog">
                                        Lihat Semua Mobil
                                        <ArrowRight className="ml-2 h-5 w-5" />
                                    </Link>
                                </Button>
                                <Button size="lg" variant="outline" className="border-2 hover:bg-blue-50 hover:border-blue-300 transition-all duration-300" asChild>
                                    <Link href="/appointment">
                                        <Phone className="mr-2 h-5 w-5" />
                                        Konsultasi Gratis
                                    </Link>
                                </Button>
                            </div>
                        </div>

                        {/* Enhanced Hero Image */}
                        <div className="relative">
                            <div className="aspect-[4/3] relative rounded-3xl overflow-hidden shadow-2xl bg-gradient-to-br from-gray-900 to-gray-700 group">
                                <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-blue-600/10 to-indigo-600/10">
                                    <Car className="h-32 w-32 text-white/80 group-hover:scale-110 transition-transform duration-300" />
                                </div>
                                {/* Overlay gradient */}
                                <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent"></div>
                            </div>

                            {/* Enhanced Floating Cards */}
                            <div className="absolute -top-6 -left-6 bg-white/95 backdrop-blur-sm rounded-xl shadow-xl p-4 max-w-[200px] border border-green-100">
                                <div className="flex items-center gap-2">
                                    <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                                        <CheckCircle className="h-4 w-4 text-green-600" />
                                    </div>
                                    <div>
                                        <div className="text-sm font-semibold text-gray-900">
                                            Garansi Resmi
                                        </div>
                                        <div className="text-xs text-gray-500">
                                            100% Terjamin
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div className="absolute -bottom-6 -right-6 bg-white/95 backdrop-blur-sm rounded-xl shadow-xl p-4 max-w-[200px] border border-yellow-100">
                                <div className="flex items-center gap-2">
                                    <div className="w-8 h-8 bg-yellow-100 rounded-full flex items-center justify-center">
                                        <Star className="h-4 w-4 text-yellow-600" />
                                    </div>
                                    <div>
                                        <div className="text-sm font-semibold text-gray-900">
                                            Rating 4.9/5
                                        </div>
                                        <div className="text-xs text-gray-500">
                                            Dari 10K+ review
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div className="absolute top-1/2 -left-4 bg-white/95 backdrop-blur-sm rounded-xl shadow-xl p-3 border border-blue-100">
                                <div className="flex items-center gap-2">
                                    <Zap className="h-4 w-4 text-blue-600" />
                                    <span className="text-xs font-medium text-gray-900">
                                        Proses Cepat
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            {/* Enhanced Search Section */}
            <section className="py-20 bg-white relative">
                <div className="absolute inset-0 bg-gradient-to-b from-gray-50/50 to-transparent"></div>
                <div className="container relative z-10">
                    <div className="text-center mb-16">
                        <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-6">
                            Cari Mobil Impian Anda
                        </h2>
                        <p className="text-lg text-gray-600 max-w-2xl mx-auto leading-relaxed">
                            Gunakan filter pencarian canggih untuk menemukan mobil yang 
                            sesuai dengan kebutuhan dan budget Anda
                        </p>
                    </div>

                    <div className="max-w-4xl mx-auto">
                        <CarSearch
                            onSearch={handleSearch}
                            showAdvancedFilters={true}
                        />
                    </div>
                </div>
            </section>

            {/* Enhanced Featured Cars */}
            <section className="py-20 bg-gradient-to-b from-gray-50 to-white">
                <div className="container">
                    <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center mb-16 gap-6">
                        <div className="space-y-4">
                            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900">
                                Mobil Pilihan Terbaik
                            </h2>
                            <p className="text-lg text-gray-600 max-w-xl">
                                Koleksi mobil bekas berkualitas tinggi yang telah melewati 
                                inspeksi ketat dari tim ahli kami
                            </p>
                        </div>
                        <Button variant="outline" size="lg" className="shrink-0 hover:bg-blue-50 hover:border-blue-300 transition-all duration-300" asChild>
                            <Link href="/catalog">
                                Lihat Semua
                                <ArrowRight className="ml-2 h-4 w-4" />
                            </Link>
                        </Button>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                        {featuredCars.map((car, index) => (
                            <div key={car.id} className="group">
                                <CarCard
                                    car={car}
                                    stockItem={car.stok_mobils?.[0]}
                                />
                            </div>
                        ))}
                    </div>

                    {featuredCars.length === 0 && (
                        <div className="text-center py-16">
                            <div className="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-6">
                                <Car className="h-12 w-12 text-gray-400" />
                            </div>
                            <h3 className="text-xl font-semibold text-gray-900 mb-3">
                                Belum ada mobil tersedia
                            </h3>
                            <p className="text-gray-600 mb-8 max-w-md mx-auto">
                                Kami sedang mempersiapkan koleksi mobil terbaik untuk Anda. 
                                Pantau terus untuk update terbaru!
                            </p>
                            <Button size="lg" asChild>
                                <Link href="/catalog">Cek Katalog Lengkap</Link>
                            </Button>
                        </div>
                    )}
                </div>
            </section>

            {/* Enhanced Features Section */}
            <section className="py-20 bg-white">
                <div className="container">
                    <div className="text-center mb-16">
                        <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-6">
                            Mengapa Memilih Kami?
                        </h2>
                        <p className="text-lg text-gray-600 max-w-2xl mx-auto">
                            Komitmen kami untuk memberikan pengalaman terbaik dalam 
                            jual beli mobil bekas
                        </p>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                        {[
                            {
                                icon: Shield,
                                title: "Garansi Resmi",
                                description: "Semua mobil dilengkapi garansi resmi dan jaminan kualitas untuk memberikan ketenangan pikiran Anda.",
                                color: "blue"
                            },
                            {
                                icon: Award,
                                title: "Inspeksi Menyeluruh",
                                description: "Setiap mobil melalui inspeksi 100+ poin oleh teknisi berpengalaman untuk memastikan kualitas terbaik.",
                                color: "green"
                            },
                            {
                                icon: Users,
                                title: "Layanan Terpercaya",
                                description: "Tim profesional siap membantu Anda dari konsultasi hingga proses transaksi selesai.",
                                color: "purple"
                            },
                            {
                                icon: Clock,
                                title: "Proses Cepat",
                                description: "Proses pembelian yang efisien dengan bantuan digitalisasi dokumen dan sistem terintegrasi.",
                                color: "yellow"
                            },
                            {
                                icon: MapPin,
                                title: "Lokasi Strategis",
                                description: "Showroom di berbagai kota dengan akses mudah dan fasilitas lengkap untuk kenyamanan Anda.",
                                color: "red"
                            },
                            {
                                icon: Car,
                                title: "Pilihan Lengkap",
                                description: "Ribuan pilihan mobil dari berbagai merek dan tahun dengan kondisi prima dan harga kompetitif.",
                                color: "indigo"
                            }
                        ].map((feature, index) => (
                            <Card key={index} className="group hover:shadow-xl transition-all duration-300 border-0 shadow-lg bg-gradient-to-br from-white to-gray-50/50">
                                <CardHeader className="text-center pb-4">
                                    <div className={`w-16 h-16 bg-${feature.color}-100 rounded-2xl flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300`}>
                                        <feature.icon className={`h-8 w-8 text-${feature.color}-600`} />
                                    </div>
                                    <CardTitle className="text-xl group-hover:text-blue-600 transition-colors">
                                        {feature.title}
                                    </CardTitle>
                                </CardHeader>
                                <CardContent className="text-center">
                                    <p className="text-gray-600 leading-relaxed">
                                        {feature.description}
                                    </p>
                                </CardContent>
                            </Card>
                        ))}
                    </div>
                </div>
            </section>

            {/* Enhanced Brands Section */}
            {mereks.length > 0 && (
                <section className="py-20 bg-gradient-to-b from-gray-50 to-white">
                    <div className="container">
                        <div className="text-center mb-16">
                            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-6">
                                Merek Populer
                            </h2>
                            <p className="text-lg text-gray-600">
                                Temukan mobil dari merek-merek terpercaya pilihan Anda
                            </p>
                        </div>

                        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-6">
                            {mereks.slice(0, 12).map((merek) => (
                                <Link
                                    key={merek.id}
                                    href={`/brand/${merek.id}`}
                                    className="group block"
                                >
                                    <Card className="text-center hover:shadow-xl transition-all duration-300 border-0 shadow-md bg-white hover:bg-blue-50">
                                        <CardContent className="p-8">
                                            <div className="w-16 h-16 bg-gray-100 rounded-2xl flex items-center justify-center mx-auto mb-4 group-hover:bg-blue-100 transition-colors duration-300 group-hover:scale-110">
                                                <Car className="h-8 w-8 text-gray-600 group-hover:text-blue-600 transition-colors" />
                                            </div>
                                            <h3 className="font-semibold text-gray-900 group-hover:text-blue-600 transition-colors">
                                                {merek.nama}
                                            </h3>
                                        </CardContent>
                                    </Card>
                                </Link>
                            ))}
                        </div>

                        <div className="text-center mt-12">
                            <Button variant="outline" size="lg" className="hover:bg-blue-50 hover:border-blue-300 transition-all duration-300" asChild>
                                <Link href="/catalog">
                                    Lihat Semua Merek
                                    <ArrowRight className="ml-2 h-4 w-4" />
                                </Link>
                            </Button>
                        </div>
                    </div>
                </section>
            )}

            {/* Enhanced CTA Section */}
            <section className="py-24 bg-gradient-to-br from-blue-600 via-blue-700 to-indigo-800 relative overflow-hidden">
                {/* Background Decoration */}
                <div className="absolute inset-0 bg-[linear-gradient(45deg,transparent_25%,rgba(255,255,255,0.05)_50%,transparent_75%)] bg-[length:60px_60px]"></div>
                <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-bl from-white/10 to-transparent rounded-full blur-3xl"></div>
                <div className="absolute bottom-0 left-0 w-96 h-96 bg-gradient-to-tr from-indigo-400/20 to-transparent rounded-full blur-3xl"></div>
                
                <div className="container text-center relative z-10">
                    <div className="max-w-4xl mx-auto">
                        <h2 className="text-3xl lg:text-5xl font-bold text-white mb-8 leading-tight">
                            Siap Menemukan Mobil Impian Anda?
                        </h2>
                        <p className="text-xl text-blue-100 mb-12 leading-relaxed max-w-2xl mx-auto">
                            Jangan tunggu lagi! Tim ahli kami siap membantu Anda menemukan 
                            mobil bekas berkualitas yang sesuai dengan kebutuhan dan budget.
                        </p>
                        <div className="flex flex-col sm:flex-row gap-6 justify-center">
                            <Button size="lg" variant="secondary" className="bg-white text-blue-600 hover:bg-gray-100 shadow-lg hover:shadow-xl transition-all duration-300" asChild>
                                <Link href="/catalog">
                                    <Car className="mr-2 h-5 w-5" />
                                    Jelajahi Katalog
                                </Link>
                            </Button>
                            <Button
                                size="lg"
                                variant="outline"
                                className="text-white border-2 border-white hover:bg-white hover:text-blue-600 transition-all duration-300"
                                asChild
                            >
                                <Link href="/appointment">
                                    <Phone className="mr-2 h-5 w-5" />
                                    Hubungi Kami
                                </Link>
                            </Button>
                        </div>
                    </div>
                </div>
            </section>
        </>
    );
}