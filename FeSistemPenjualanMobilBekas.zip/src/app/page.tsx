"use client";

import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import CarSearch from "@/components/car/car-search";
import StockCarCard from "@/components/car/stock-car-card";
import { useCatalog, useMereks } from "@/lib/hooks";
import type { StokMobil, Merek } from "@/lib/types";
import {
    Car,
    Shield,
    Award,
    Users,
    ArrowRight,
    CheckCircle,
    Star,
    Clock,
    MapPin,
    Phone,
} from "lucide-react";
import type { CarSearchFilters } from "@/lib/validations";

export default function HomePage() {
    const { data: stockCarsData } = useCatalog({ page: 1 });
    const { data: mereksData } = useMereks();
    const featuredStockCars: StokMobil[] =
        stockCarsData?.data?.slice(0, 6) || [];
    const mereks: Merek[] = mereksData?.data || [];

    const handleSearch = (filters: CarSearchFilters) => {
        const params = new URLSearchParams();
        Object.entries(filters).forEach(([key, value]) => {
            if (value !== undefined && value !== "") {
                params.set(key, value.toString());
            }
        });
        window.location.href = `/mobil?${params.toString()}`;
    };

    return (
        <div className="min-h-screen">
            {/* Hero Section */}
            <section className="relative bg-gradient-to-br from-blue-50 to-indigo-100 py-16 lg:py-24">
                <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-7xl relative z-10">
                    <div className="grid lg:grid-cols-2 gap-8 lg:gap-12 items-center">
                        <div className="space-y-6 lg:space-y-8">
                            <div className="space-y-4">
                                <Badge variant="secondary" className="w-fit text-sm">
                                    Platform Terpercaya #1 di Indonesia
                                </Badge>
                                <h1 className="text-3xl sm:text-4xl lg:text-5xl xl:text-6xl font-bold text-gray-900 leading-tight">
                                    Temukan
                                    <span className="text-blue-600 block">
                                        Mobil Bekas
                                    </span>
                                    Impian Anda
                                </h1>
                                <p className="text-lg lg:text-xl text-gray-600 leading-relaxed max-w-lg">
                                    Ribuan pilihan mobil bekas berkualitas
                                    dengan harga terbaik. Garansi resmi,
                                    pemeriksaan menyeluruh, dan layanan
                                    terpercaya.
                                </p>
                            </div>

                            {/* Statistics */}
                            <div className="grid grid-cols-3 gap-4 lg:gap-6">
                                <div className="text-center">
                                    <div className="text-2xl lg:text-3xl font-bold text-blue-600">
                                        1000+
                                    </div>
                                    <div className="text-xs lg:text-sm text-gray-600">
                                        Mobil Tersedia
                                    </div>
                                </div>
                                <div className="text-center">
                                    <div className="text-2xl lg:text-3xl font-bold text-blue-600">
                                        50K+
                                    </div>
                                    <div className="text-xs lg:text-sm text-gray-600">
                                        Pelanggan Puas
                                    </div>
                                </div>
                                <div className="text-center">
                                    <div className="text-2xl lg:text-3xl font-bold text-blue-600">
                                        98%
                                    </div>
                                    <div className="text-xs lg:text-sm text-gray-600">
                                        Rating Kepuasan
                                    </div>
                                </div>
                            </div>

                            {/* CTA Buttons */}
                            <div className="flex flex-col sm:flex-row gap-3 lg:gap-4">
                                <Button size="lg" className="w-full sm:w-auto" asChild>
                                    <Link href="/mobil">
                                        Lihat Semua Mobil
                                        <ArrowRight className="ml-2 h-5 w-5" />
                                    </Link>
                                </Button>
                                <Button size="lg" variant="outline" className="w-full sm:w-auto" asChild>
                                    <Link href="/janji-temu">
                                        <Phone className="mr-2 h-5 w-5" />
                                        Konsultasi Gratis
                                    </Link>
                                </Button>
                            </div>
                        </div>

                        {/* Hero Image */}
                        <div className="relative mt-8 lg:mt-0">
                            <div className="aspect-[4/3] relative rounded-2xl overflow-hidden shadow-2xl bg-gray-200">
                                <div className="w-full h-full flex items-center justify-center">
                                    <Car className="h-16 lg:h-24 w-16 lg:w-24 text-gray-400" />
                                </div>
                            </div>

                            {/* Floating Cards */}
                            <div className="absolute -top-2 -left-2 lg:-top-4 lg:-left-4 bg-white rounded-lg shadow-lg p-3 lg:p-4 max-w-[160px] lg:max-w-[200px]">
                                <div className="flex items-center gap-2">
                                    <CheckCircle className="h-4 w-4 lg:h-5 lg:w-5 text-green-500" />
                                    <span className="text-xs lg:text-sm font-medium">
                                        Garansi Resmi
                                    </span>
                                </div>
                            </div>

                            <div className="absolute -bottom-2 -right-2 lg:-bottom-4 lg:-right-4 bg-white rounded-lg shadow-lg p-3 lg:p-4 max-w-[160px] lg:max-w-[200px]">
                                <div className="flex items-center gap-2">
                                    <Star className="h-4 w-4 lg:h-5 lg:w-5 text-yellow-500" />
                                    <span className="text-xs lg:text-sm font-medium">
                                        Rating 4.9/5
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            {/* Search Section */}
            <section className="py-12 lg:py-16 bg-white">
                <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-7xl">
                    <div className="text-center mb-8 lg:mb-12">
                        <h2 className="text-2xl lg:text-3xl font-bold text-gray-900 mb-3 lg:mb-4">
                            Cari Mobil Impian Anda
                        </h2>
                        <p className="text-gray-600 max-w-2xl mx-auto text-sm lg:text-base">
                            Gunakan filter pencarian untuk menemukan mobil yang
                            sesuai dengan kebutuhan dan budget Anda
                        </p>
                    </div>

                    <div className="max-w-4xl mx-auto">
                        <CarSearch
                            onSearch={handleSearch}
                            showAdvancedFilters={true}
                        />
                    </div>
                </div>
            </section>

            {/* Featured Cars */}
            <section className="py-12 lg:py-16 bg-gray-50">
                <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-7xl">
                    <div className="flex flex-col lg:flex-row lg:justify-between lg:items-center mb-8 lg:mb-12 gap-4">
                        <div>
                            <h2 className="text-2xl lg:text-3xl font-bold text-gray-900 mb-3 lg:mb-4">
                                Mobil Pilihan Terbaik
                            </h2>
                            <p className="text-gray-600 text-sm lg:text-base">
                                Koleksi mobil bekas berkualitas tinggi yang
                                telah melewati inspeksi ketat
                            </p>
                        </div>
                        <Button variant="outline" className="w-fit" asChild>
                            <Link href="/mobil">
                                Lihat Semua
                                <ArrowRight className="ml-2 h-4 w-4" />
                            </Link>
                        </Button>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 lg:gap-6">
                        {featuredStockCars.map((stockCar) => (
                            <StockCarCard
                                key={stockCar.id}
                                stockCar={stockCar}
                            />
                        ))}
                    </div>

                    {featuredStockCars.length === 0 && (
                        <div className="text-center py-12">
                            <Car className="mx-auto h-12 lg:h-16 w-12 lg:w-16 text-gray-400 mb-4" />
                            <h3 className="text-lg font-medium text-gray-900 mb-2">
                                Belum ada mobil tersedia
                            </h3>
                            <p className="text-gray-600 mb-6 text-sm lg:text-base max-w-md mx-auto">
                                Kami sedang mempersiapkan koleksi mobil terbaik
                                untuk Anda
                            </p>
                            <Button asChild>
                                <Link href="/mobil">Cek Katalog Lengkap</Link>
                            </Button>
                        </div>
                    )}
                </div>
            </section>

            {/* Features Section */}
            <section className="py-12 lg:py-16 bg-white">
                <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-7xl">
                    <div className="text-center mb-8 lg:mb-12">
                        <h2 className="text-2xl lg:text-3xl font-bold text-gray-900 mb-3 lg:mb-4">
                            Mengapa Memilih Kami?
                        </h2>
                        <p className="text-gray-600 max-w-2xl mx-auto text-sm lg:text-base">
                            Komitmen kami untuk memberikan layanan terbaik dalam
                            jual beli mobil bekas
                        </p>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 lg:gap-8">
                        <Card className="text-center hover:shadow-lg transition-shadow duration-300">
                            <CardHeader className="pb-4">
                                <div className="w-12 h-12 lg:w-16 lg:h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-3 lg:mb-4">
                                    <Shield className="h-6 w-6 lg:h-8 lg:w-8 text-blue-600" />
                                </div>
                                <CardTitle className="text-lg lg:text-xl">Garansi Resmi</CardTitle>
                            </CardHeader>
                            <CardContent className="pt-0">
                                <p className="text-gray-600 text-sm lg:text-base">
                                    Semua mobil dilengkapi garansi resmi dan
                                    jaminan kualitas untuk memberikan ketenangan
                                    pikiran Anda.
                                </p>
                            </CardContent>
                        </Card>

                        <Card className="text-center hover:shadow-lg transition-shadow duration-300">
                            <CardHeader className="pb-4">
                                <div className="w-12 h-12 lg:w-16 lg:h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-3 lg:mb-4">
                                    <Award className="h-6 w-6 lg:h-8 lg:w-8 text-green-600" />
                                </div>
                                <CardTitle className="text-lg lg:text-xl">Inspeksi Menyeluruh</CardTitle>
                            </CardHeader>
                            <CardContent className="pt-0">
                                <p className="text-gray-600 text-sm lg:text-base">
                                    Setiap mobil melalui inspeksi 100+ poin oleh
                                    teknisi berpengalaman untuk memastikan
                                    kualitas terbaik.
                                </p>
                            </CardContent>
                        </Card>

                        <Card className="text-center hover:shadow-lg transition-shadow duration-300">
                            <CardHeader className="pb-4">
                                <div className="w-12 h-12 lg:w-16 lg:h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-3 lg:mb-4">
                                    <Users className="h-6 w-6 lg:h-8 lg:w-8 text-purple-600" />
                                </div>
                                <CardTitle className="text-lg lg:text-xl">Layanan Terpercaya</CardTitle>
                            </CardHeader>
                            <CardContent className="pt-0">
                                <p className="text-gray-600 text-sm lg:text-base">
                                    Tim profesional siap membantu Anda dari
                                    konsultasi hingga proses transaksi selesai.
                                </p>
                            </CardContent>
                        </Card>

                        <Card className="text-center hover:shadow-lg transition-shadow duration-300">
                            <CardHeader className="pb-4">
                                <div className="w-12 h-12 lg:w-16 lg:h-16 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-3 lg:mb-4">
                                    <Clock className="h-6 w-6 lg:h-8 lg:w-8 text-yellow-600" />
                                </div>
                                <CardTitle className="text-lg lg:text-xl">Proses Cepat</CardTitle>
                            </CardHeader>
                            <CardContent className="pt-0">
                                <p className="text-gray-600 text-sm lg:text-base">
                                    Proses pembelian yang efisien dengan bantuan
                                    digitalisasi dokumen dan sistem
                                    terintegrasi.
                                </p>
                            </CardContent>
                        </Card>

                        <Card className="text-center hover:shadow-lg transition-shadow duration-300">
                            <CardHeader className="pb-4">
                                <div className="w-12 h-12 lg:w-16 lg:h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-3 lg:mb-4">
                                    <MapPin className="h-6 w-6 lg:h-8 lg:w-8 text-red-600" />
                                </div>
                                <CardTitle className="text-lg lg:text-xl">Lokasi Strategis</CardTitle>
                            </CardHeader>
                            <CardContent className="pt-0">
                                <p className="text-gray-600 text-sm lg:text-base">
                                    Showroom di berbagai kota dengan akses mudah
                                    dan fasilitas lengkap untuk kenyamanan Anda.
                                </p>
                            </CardContent>
                        </Card>

                        <Card className="text-center hover:shadow-lg transition-shadow duration-300">
                            <CardHeader className="pb-4">
                                <div className="w-12 h-12 lg:w-16 lg:h-16 bg-indigo-100 rounded-full flex items-center justify-center mx-auto mb-3 lg:mb-4">
                                    <Car className="h-6 w-6 lg:h-8 lg:w-8 text-indigo-600" />
                                </div>
                                <CardTitle className="text-lg lg:text-xl">Pilihan Lengkap</CardTitle>
                            </CardHeader>
                            <CardContent className="pt-0">
                                <p className="text-gray-600 text-sm lg:text-base">
                                    Ribuan pilihan mobil dari berbagai merek dan
                                    tahun dengan kondisi prima dan harga
                                    kompetitif.
                                </p>
                            </CardContent>
                        </Card>
                    </div>
                </div>
            </section>

            {/* Brands Section */}
            {mereks.length > 0 && (
                <section className="py-12 lg:py-16 bg-gray-50">
                    <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-7xl">
                        <div className="text-center mb-8 lg:mb-12">
                            <h2 className="text-2xl lg:text-3xl font-bold text-gray-900 mb-3 lg:mb-4">
                                Merek Populer
                            </h2>
                            <p className="text-gray-600 text-sm lg:text-base">
                                Temukan mobil dari merek-merek terpercaya
                                pilihan Anda
                            </p>
                        </div>

                        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3 lg:gap-6">
                            {mereks.slice(0, 12).map((merek) => (
                                <Link
                                    key={merek.id}
                                    href={`/mobil?merek=${merek.id}`}
                                    className="group block"
                                >
                                    <Card className="text-center hover:shadow-lg transition-all duration-300 hover:-translate-y-1">
                                        <CardContent className="p-4 lg:p-6">
                                            <div className="w-12 h-12 lg:w-16 lg:h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-3 lg:mb-4 group-hover:bg-blue-100 transition-colors">
                                                <Car className="h-6 w-6 lg:h-8 lg:w-8 text-gray-600 group-hover:text-blue-600" />
                                            </div>
                                            <h3 className="text-sm lg:text-base font-medium text-gray-900 group-hover:text-blue-600 transition-colors">
                                                {merek.nama}
                                            </h3>
                                        </CardContent>
                                    </Card>
                                </Link>
                            ))}
                        </div>

                        <div className="text-center mt-6 lg:mt-8">
                            <Button variant="outline" asChild>
                                <Link href="/mobil">
                                    Lihat Semua Merek
                                    <ArrowRight className="ml-2 h-4 w-4" />
                                </Link>
                            </Button>
                        </div>
                    </div>
                </section>
            )}

            {/* CTA Section */}
            <section className="py-16 lg:py-20 bg-blue-600">
                <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-4xl text-center">
                    <div className="space-y-6 lg:space-y-8">
                        <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-white">
                            Siap Menemukan Mobil Impian Anda?
                        </h2>
                        <p className="text-lg lg:text-xl text-blue-100 max-w-2xl mx-auto">
                            Jangan tunggu lagi! Tim ahli kami siap membantu Anda
                            menemukan mobil bekas berkualitas yang sesuai dengan
                            kebutuhan dan budget.
                        </p>
                        <div className="flex flex-col sm:flex-row gap-3 lg:gap-4 justify-center">
                            <Button size="lg" variant="secondary" className="w-full sm:w-auto" asChild>
                                <Link href="/mobil">
                                    <Car className="mr-2 h-5 w-5" />
                                    Jelajahi Katalog
                                </Link>
                            </Button>
                            <Button
                                size="lg"
                                variant="outline"
                                className="w-full sm:w-auto text-white border-white hover:bg-white hover:text-blue-600"
                                asChild
                            >
                                <Link href="/janji-temu">
                                    <Phone className="mr-2 h-5 w-5" />
                                    Hubungi Kami
                                </Link>
                            </Button>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    );
}