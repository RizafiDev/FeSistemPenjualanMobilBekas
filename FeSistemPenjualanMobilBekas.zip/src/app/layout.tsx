import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import Layout from "@/components/layout/layout";
import { Toaster } from "@/components/ui/sonner";

const inter = Inter({
    subsets: ["latin"],
    variable: "--font-inter",
    display: "swap",
});

export const metadata: Metadata = {
    metadataBase: new URL(
        process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000"
    ),
    title: {
        default: "Mobil Bekas Berkualitas | Sistem Penjualan Mobil Bekas",
        template: "%s | Sistem Penjualan Mobil Bekas"
    },
    description:
        "Temukan mobil bekas berkualitas dengan harga terbaik. Berbagai merek dan model tersedia dengan garansi dan pelayanan terpercaya di seluruh Indonesia.",
    keywords: [
        "mobil bekas",
        "jual mobil bekas",
        "beli mobil bekas",
        "mobil second",
        "showroom mobil",
        "mobil berkualitas",
        "garansi mobil"
    ],
    authors: [{ name: "Sistem Penjualan Mobil Bekas" }],
    creator: "Sistem Penjualan Mobil Bekas",
    publisher: "Sistem Penjualan Mobil Bekas",
    formatDetection: {
        email: false,
        address: false,
        telephone: false,
    },
    openGraph: {
        type: "website",
        locale: "id_ID",
        url: process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000",
        title: "Mobil Bekas Berkualitas | Sistem Penjualan Mobil Bekas",
        description: "Temukan mobil bekas berkualitas dengan harga terbaik. Berbagai merek dan model tersedia dengan garansi dan pelayanan terpercaya.",
        siteName: "Sistem Penjualan Mobil Bekas",
    },
    twitter: {
        card: "summary_large_image",
        title: "Mobil Bekas Berkualitas | Sistem Penjualan Mobil Bekas",
        description: "Temukan mobil bekas berkualitas dengan harga terbaik. Berbagai merek dan model tersedia dengan garansi dan pelayanan terpercaya.",
    },
    robots: {
        index: true,
        follow: true,
        googleBot: {
            index: true,
            follow: true,
            'max-video-preview': -1,
            'max-image-preview': 'large',
            'max-snippet': -1,
        },
    },
    verification: {
        google: process.env.NEXT_PUBLIC_GOOGLE_SITE_VERIFICATION,
    },
};

export default function RootLayout({
    children,
}: Readonly<{
    children: React.ReactNode;
}>) {
    return (
        <html lang="id" className="scroll-smooth">
            <head>
                <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover" />
                <meta name="theme-color" content="#2563eb" />
                <meta name="color-scheme" content="light" />
                <link rel="icon" href="/favicon.ico" sizes="any" />
                <link rel="icon" href="/icon.svg" type="image/svg+xml" />
                <link rel="apple-touch-icon" href="/apple-touch-icon.png" />
                <link rel="manifest" href="/manifest.json" />
            </head>
            <body 
                className={`${inter.variable} font-sans antialiased bg-white text-gray-900 selection:bg-blue-100 selection:text-blue-900`}
                suppressHydrationWarning
            >
                <div className="min-h-screen flex flex-col w-full overflow-x-hidden">
                    <Layout>{children}</Layout>
                </div>
                <Toaster 
                    position="top-right"
                    expand={false}
                    richColors
                    closeButton
                    toastOptions={{
                        duration: 4000,
                        className: "font-sans",
                    }}
                />
            </body>
        </html>
    );
}